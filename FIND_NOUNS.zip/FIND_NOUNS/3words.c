#include <stdio.h>
#include <ctype.h>

// Function to display the first three words in a file
void displayFirstThreeWords(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Failed to open the file.\n");
        return;
    }

    int words_found = 0;
    int c;
    int in_word = 0;

    printf("First three words:\n");

    while ((c = fgetc(file)) != EOF && words_found < 3) {
        if (isspace(c)) {
            if (in_word) {
                // End of a word
                in_word = 0;
            }
        } else {
            if (!in_word) {
                // Start of a new word
                in_word = 1;
                // To print the word, we need to buffer characters
                // For simplicity, we can store the word in a small buffer
                char word[100];
                int index = 0;

                // Collect characters for the current word
                do {
                    if (index < sizeof(word) - 1) {
                        word[index++] = c;
                    }
                    c = fgetc(file);
                } while (c != EOF && !isspace(c));

                word[index] = '\0'; // Null-terminate the word

                printf("%s\n", word);
                words_found++;
            }
        }
    }

    fclose(file);
}

int main(){
    displayFirstThreeWords("nouns.txt");
}