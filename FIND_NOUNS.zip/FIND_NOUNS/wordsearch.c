#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 256

/*
Windows uses a two-character sequence, carriage return + line feed (\r\n or CRLF), 
while Unix/Linux/macOS uses a single line feed character (\n or LF)
macOS CR \r
linux    \n
windows  \r\n
so file nouns.txt should be saved using the same ending as in line 28 CRLF (\n)

*/

// Function to check if the word exists in the file
int is_word_in_file(const char *filename, const char *word) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return 0; // Not found due to error
    }

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), file)) {
        // Remove trailing newline character
        line[strcspn(line, "\r\n")] = 0;                     //here ending is important

        if (strcmp(line, word) == 0) {
            fclose(file);
            return 1; // Word found
        }
    }

    fclose(file);
    return 0; // Word not found
}

int main() {
    char filename[256];
    char word[256];

    printf("Enter the filename of the word list (.txt): ");
    if (scanf("%255s", filename) != 1) {
        fprintf(stderr, "Invalid input.\n");
        return 1;
    }

    printf("Enter the word to search: ");
    if (scanf("%255s", word) != 1) {
        fprintf(stderr, "Invalid input.\n");
        return 1;
    }

    if (is_word_in_file(filename, word)) {
        printf("The word \"%s\" is in the list.\n", word);
    } else {
        printf("The word \"%s\" is NOT in the list.\n", word);
    }

    return 0;
}
